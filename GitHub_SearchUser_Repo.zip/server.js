var express=require("express");
var http=require("http");
var path=require("path");
var app=express();
app.use(express.static(path.join(__dirname)));
app.get('*'),(req,res)=>{
res.sendFile(path.join(__dirname,'index.html'));
};
var port=process.env.port || 4200;
var server=http.createServer(app);
server.listen(port,()=>console.log('server is running on 4200 port'));