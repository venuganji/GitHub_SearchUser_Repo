app.config(function($routeProvider) {
    $routeProvider
       
    .when("/users/:uname", {
        templateUrl : "Views/userView.html",
        controller: 'userInfoController'
    }).
     otherwise({
         redirectTo: '/'
      });
   
});