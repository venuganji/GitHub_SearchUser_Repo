app.controller("searchController",["$scope","$http","$filter","$location","$route",function($scope,$http,$filter,$location,$route){
    $scope.showuserInfo=false;   
    //When click on Search button this function will call
    $scope.doSearch=function(){ 
        if($scope.searchuser=="" || $scope.searchuser==undefined){      
            $scope.Error="Enter login name";
            $('#error-popup').modal({
                backdrop: 'static',
                keyboard: false
		    });
            
        }else{
            
            $location.path('users/'+$scope.searchuser);
  
         
        }
    }
    //When click on header logo this function will call. It will navigate to main route. 
    $scope.gotoRoot=function(){
        $location.path("/");
        $scope.searchuser="";
        
        
    }
          
}]);





