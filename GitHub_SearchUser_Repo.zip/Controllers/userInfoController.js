app.controller("userInfoController",["$scope","$routeParams","$http", "$q",function($scope,$routeParams,$http, $q){    
   
    var apiUrl="https://api.github.com/users/";
    var url1 = $http.get(apiUrl+$routeParams.uname);
    var url2 = $http.get(apiUrl+$routeParams.uname+"/repos");  
    var userAllLanguages=[];
    $scope.userLanguage=[];
    /// Backend Calls
    $q.all([url1, url2]).then(function(response){
         $scope.showuserInfo=true;        
          $scope.userInfo = response[0].data;                
          $scope.user_avatar=$scope.userInfo.avatar_url;     
          $scope.showuserInfo=true;
          $scope.userRepos = response[1].data;
        for(var i=0;i<response[1].data.length;i++){                      
            if(response[1].data[i].language!==null){
                userAllLanguages.push(response[1].data[i].language);   
                
            }
       
        }
        ///Removing Duplicates for user languages
        $scope.userLanguage=removeDups(userAllLanguages);
        
        }, function() {
        
            $scope.Error="Enter Correct Username";
            $('#error-user-popup').modal({
                backdrop: 'static',
                keyboard: false
		    });
                           
    });
  
    
}])
//Function for Removing duplicates
function removeDups(arr){ 
	var newArr = [];
	angular.forEach(arr, function(value, key) {
		var exists = false;
		angular.forEach(newArr, function(val2, key) {
			if(angular.equals(value, val2)){
                exists = true 
            }; 
		});
		if(exists == false && value!= "") { newArr.push(value); }
	});
  return newArr;
}









